export default function New() {
    addEventListener("DOMContentLoaded", () => {
        // let shamin = document.getElementById("myCheck"); // Use let for potential modification
        // console.log(shamin.click());

        // Add your code to interact with the element here (if needed)
        console.log('hello')
    });
    return (
        <>

        </>
    )
}
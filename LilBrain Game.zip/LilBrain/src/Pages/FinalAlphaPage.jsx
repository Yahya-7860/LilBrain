import React from 'react'
import Score from '../components/Score'
import AlphaPage from './AlphaPage'

function FinalAlphaPage() {
  return (
    <div>
        <AlphaPage/>


    </div>
  )
}

export default FinalAlphaPage